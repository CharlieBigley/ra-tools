<?php

/*
 * @version    3.3.13
 * @component  com_ra_tools
 * @author     Charlie Bigley <webmaster@bigley.me.uk>
 * @copyright  2023 Charlie Bigley
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * 17/06/23 CB remove reference to a.hosted
 * 03/09/23 CB use ToolsHelper, not BackendHelper
 * 08/11/24 CB filter by nation
 * 28/04/25 CB leftJoin on areas
 * 08/09/25 CB select a.*
 */

namespace Ramblers\Component\Ra_tools\Site\Model;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
//use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\MVC\Model\ListModel;
use Ramblers\Component\Ra_tools\Site\Helpers\ToolsHelper;

class Group_listModel extends ListModel {

    protected $filter_fields;

    public function __construct($config = []) {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = array(
                'a.code',
                'a.name',
                'a.website',
                'a.co_url',
                'areas.name',
            );
            $this->filter_fields = $config['filter_fields'];
        }
        parent::__construct($config);
    }

    protected function getListQuery() {
        $db = $this->getDbo();
        $query = $db->getQuery(true);

        $query->select('a.*');
        $query->select("areas.name as area");

        $query->from('`#__ra_groups` AS a');
        $query->leftJoin('#__ra_areas AS areas ON areas.id = a.area_id');

        // Filter by nation
        $nation_id = (int) $this->getState('filter.nation_id');
        if ($nation_id != 0) {
            $query->where('areas.nation_id =' . $nation_id);
        }

        // Filter by search
        $search = $this->getState('filter.search');

        if (!empty($search)) {
            if (stripos($search, 'id:') === 0) {
                $query->where('a.id = ' . (int) substr($search, 3));
            } else {
                $query = ToolsHelper::buildSearchQuery($search, $this->filter_fields, $query);
            }
        }

        // Add the list ordering clause, default to name ASC
        $orderCol = $this->state->get('list.ordering', 'a.name');
        $orderDirn = $this->state->get('list.direction', 'asc');

        $query->order($db->escape($orderCol . ' ' . $orderDirn));
        if (JDEBUG) {
            Factory::getApplication()->enqueueMessage('sql = ' . $this->_db->replacePrefix($query), 'notice');
        }
        return $query;
    }

    protected function populateState($ordering = 'a.name', $direction = 'asc') {
        // List state information.
        parent::populateState($ordering, $direction);
    }

}
