
<?php

/**
 * @version     3.3.15
 * @package     com_ra_tools
 * @copyright   Copyright (C) 2020. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Charlie <webmaster@bigley.me.uk> - https://www.stokeandnewcastleramblers.org.uk
 * 04/02/24 CB created
 * 04/03/24 CB show remote website as a link
 * 05/03/24 Don't display heading from the menu
 * 17/08/25 CB use api_site
 * 14/09/25 CB set up maximum time of 5 minutes
 */
// No direct access

use Joomla\CMS\Factory;
use Ramblers\Component\Ra_tools\Site\Helpers\ToolsHelper;

defined('_JEXEC') or die;

//echo '<h2>' . $this->params->get('page_title') . '</h2>';

$page_intro = $this->menu_params->get('page_intro');
$site_id = $this->menu_params->get('site_id', 0);
if ($site_id == 0) {
    Factory::getApplication()->enqueueMessage('Site id not specified ', 'error');
    return;
}
$id = $this->menu_params->get('id', 10);
$show_details = $this->menu_params->get('show_details', '');

$sql = 'SELECT url,token,colour FROM #__ra_api_sites ';
$sql .= 'WHERE id=' . $site_id;
$site = $this->toolsHelper->getItem($sql);

$website = $site->url;
$token = $site->token;

if (!$page_intro == '') {
    echo $page_intro . '<br>';
}
//      set up maximum time of 5 minutes
$max = 5 * 60;
set_time_limit($max);

// code fom https://slides.woluweb.be/api/api.html
$curl = curl_init();
$url = $website . '/api/index.php/v1/content/articles/';
//
// HTTP request headers
$headers = [
    'Accept: application/vnd.api+json',
    'Content-Type: application/json',
    sprintf('X-Joomla-Token: %s', trim($token)),
];

curl_setopt_array($curl, [
    CURLOPT_URL => $url . $id,
    CURLOPT_HEADER => false, // do not include header in output
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => 'utf-8',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2TLS,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_HTTPHEADER => $headers,
        //        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false); // do not follow redirects
        //        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // do not output result
        //        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20); // allow xx seconds for timeout
        //    curl_setopt($ch, CURLOPT_REFERER, JURI::base()); // say who wants the feed
        //        curl_setopt($ch, CURLOPT_REFERER, "com_ra_tools"); // say who wants the feed
        ]
);
$response = curl_exec($curl);

if (curl_errno($curl)) {
    echo curl_error($curl);
}
curl_close($curl);
//echo '<b>Start of response</b><br>';
////echo $response;
//echo '<br><b>End of response</b><br>';
//echo $response->body;
//echo '<br>';

$details = json_decode($response, true);
if (!is_null($details["errors"])) {
    echo "response is $response<br>";
    var_dump($details["errors"]);
    Factory::getApplication()->enqueueMessage('Errors ', 'error');
    return;
}
$data = $details["data"];
$attributes = $data["attributes"];

$created = $attributes['created'];
$modified = $attributes['modified'];
$title = $attributes['title'];
$text = $attributes['text'];
echo '<!-- start of code from ' . __FILE__ . '  -->' . PHP_EOL;
//
echo '<!-- start of JSON data  -->' . PHP_EOL;
echo'<div style="background: ' . $site->colour . '; padding-top: 10px; ">';
echo '<h2>' . $title . '</h2>';
echo $text . '<br>';

echo '<b>Created</b> ' . $created . '<br>';
if (!$modified == '') {
    echo '<b>Modified</b> ' . $modified . '<br>';
}
echo'</div>';
if ($show_details == 'Y') {
    echo "<i>(Showing article $id from ";
    echo $this->toolsHelper->buildLink($website, $website, true);
    echo ')</i><br>';
}
