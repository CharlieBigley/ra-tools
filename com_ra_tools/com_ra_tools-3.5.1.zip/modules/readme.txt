This module does not get installed
Install separately from git/ra_events_mod_ra_tools
